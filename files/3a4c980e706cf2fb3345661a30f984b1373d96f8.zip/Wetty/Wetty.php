<?php namespace App\SupportedApps\Wetty;

class Wetty extends \App\SupportedApps
{
}
