<ul class="livestats">
    <li>
        <span class="title">Queries</span>
        <strong>{!! $dns_queries !!}</strong>
    </li>
    <li>
        <span class="title">Blocked</span>
        <strong>{!! $blocked_filtering !!}</strong>
    </li>
</ul>
