<?php namespace App\SupportedApps\ownCloud;

class ownCloud extends \App\SupportedApps
{
}
