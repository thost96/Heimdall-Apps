<?php namespace App\SupportedApps\pfSense;

class pfSense extends \App\SupportedApps
{
}
