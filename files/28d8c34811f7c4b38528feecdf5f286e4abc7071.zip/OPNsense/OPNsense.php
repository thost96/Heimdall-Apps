<?php namespace App\SupportedApps\OPNsense;

class OPNsense extends \App\SupportedApps
{
}
