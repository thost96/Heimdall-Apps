<?php namespace App\SupportedApps\WireGuard;

class WireGuard extends \App\SupportedApps
{
}
