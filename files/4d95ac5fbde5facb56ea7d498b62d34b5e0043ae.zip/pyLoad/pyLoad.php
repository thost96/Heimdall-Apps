<?php namespace App\SupportedApps\pyLoad;

class pyLoad extends \App\SupportedApps
{
}
