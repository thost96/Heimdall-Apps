<?php namespace App\SupportedApps\Traccar;

class Traccar extends \App\SupportedApps
{
}
