<?php namespace App\SupportedApps\pgAdmin;

class pgAdmin extends \App\SupportedApps
{
}
