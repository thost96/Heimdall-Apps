<ul class="livestats">
    <li>
        <span class="title">Instances</span>
        <strong>{!! $instances !!}</strong>
    </li>
    <li>
        <span class="title">Outages</span>
        <strong>{!! $outages !!}</strong>
    </li>
</ul>
