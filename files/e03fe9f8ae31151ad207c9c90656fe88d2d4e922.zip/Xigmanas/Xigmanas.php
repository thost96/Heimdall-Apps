<?php namespace App\SupportedApps\Xigmanas;

class Xigmanas extends \App\SupportedApps
{
}
